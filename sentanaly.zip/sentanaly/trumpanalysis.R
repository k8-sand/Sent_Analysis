#RESTART R session!
#this method avoids explicit handshake
#had to set up a developer account through Twitter
#create new app
#used my wordpress as my website
#callback URL WAS: http://127.0.0.1:1410
library(devtools)
library(twitteR)
library(SnowballC)
library(tm)
library(syuzhet)

consumerKey <- "ZKPNweFiEevZ44LunMTm7Zdvb"
consumerSecret <- "7xivTtVRJZ6yz5IfMOYtn9fXXm6AwGy2drWHbpNXqPvbcDPpRi"
accessToken <- "4175840296-Q0lpwHThWNalIsQlOLNuatvC5HzbAeNhtKYLqOD"
accessTokenSecret <- "5ZEXZNlwfTo3MgYNabAAa8yzIyDWAsZ1sIJJnMr5anW4g"

setup_twitter_oauth(consumerKey, consumerSecret, accessToken, accessTokenSecret)

tweets <- userTimeline("realDonaldTrump", n=200)
n.tweet <-length(tweets)

#cleaning the tweets 
tweets.df <- twListToDF(tweets)
head(tweets.df)
# so we have 16 variables
#text is the tweet part, hashtags, urls...so we need to remove
#the hashtags and urls so we just have the text part
tweets.df2 <- gsub('http.*',"", tweets.df$text)
tweets.df2 <- gsub('https.*',"", tweets.df2)
tweets.df2 <- gsub('#.*',"", tweets.df2)
tweets.df2 <- gsub('@.*',"", tweets.df2)

#we will now try and get the emotion score for each tweet
#syuzhet package has 10 emotions
#anger anticipation disgust fear joy sadness surprise trust negative postive

word.df <-as.vector(tweets.df2)
emotion.df<-get_nrc_sentiment(word.df)
emotion.df2<-cbind(tweets.df2,emotion.df)
head(emotion.df2)

#now we use the get sentiment fxn to extract
#sentiment score for each of the tweets
sent.value<-get_sentiment(word.df)
most.positive<-word.df[sent.value == max(sent.value)]
#view most positive tweet
most.positive

most.negative<-word.df[sent.value <= min(sent.value)]
#view most negative
most.negative

#let's view the scores
sent.value

#now segregate pos and neg tweets based on scores
#assigned to each of the tweets

pos.tweet <-word.df[sent.value>0]
neg.tweet <-word.df[sent.value<0]
neutral.tweet<-word.df[sent.value == 0]

#one line code to segregate
cat_sent1 <- ifelse(sent.value < 0, "Negative", ifelse(sent.value > 0, "Positive", "Neutral"))
cat_sent2 <- cbind(tweets, cat_sent1, sent.value)
head(cat_sent2)

#viewing the total number of tweets by sent.
table(cat_sent1)

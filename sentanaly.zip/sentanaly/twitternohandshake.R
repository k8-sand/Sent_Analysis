#RESTART R session!
#this method avoids explicit handshake
#had to set up a developer account through Twitter
#create new app
#used my wordpress as my website
#callback URL WAS: http://127.0.0.1:1410
library(devtools)
library(twitteR)

consumerKey <- "ZKPNweFiEevZ44LunMTm7Zdvb"
consumerSecret <- "7xivTtVRJZ6yz5IfMOYtn9fXXm6AwGy2drWHbpNXqPvbcDPpRi"
accessToken <- "4175840296-Q0lpwHThWNalIsQlOLNuatvC5HzbAeNhtKYLqOD"
accessTokenSecret <- "5ZEXZNlwfTo3MgYNabAAa8yzIyDWAsZ1sIJJnMr5anW4g"

setup_twitter_oauth(consumerKey, consumerSecret, accessToken, accessTokenSecret)

#looking at 1500 most recent tweets with @delta
delta.tweets = searchTwitter('@delta',n=1500)

#LET'S TAKE A LOOK AT THE FIRST TWEET IN THIS
tweet = delta.tweets[[1]]
class(tweet) #this tells us that this tweet is of the 'status'object type
tweet$getScreenName() #this tells us who made the tweet
tweet$getText() #this gives us the exact tweet

#upload .txt data

#concatenate a few slang words 
pos.words = c(positive.words, 'yas', 'yus','retweet')
neg.words = c(negative.words, 'wtf','wait','smh','epicfail','stupid','racist','retard','why')
#instal plyr package to use laply
library(plyr)
delta.text = laply(delta.tweets, function(t)t$getText())
head(delta.text, 5)

#copied function from
#https://stackoverflow.com/questions/35222946/score-sentiment-function-in-r-return-always-0
score.sentiment = function(sentences, pos.words, neg.words, .progress='none')
{
  require(plyr);
  require(stringr);
  scores = laply(sentences, function(sentence, pos.words, neg.words) {
    sentence = gsub('[^A-z ]','', sentence)
    sentence = tolower(sentence);
    word.list = str_split(sentence, '\\s+');
    words = unlist(word.list);
    pos.matches = match(words, pos.words);
    neg.matches = match(words, neg.words);
    pos.matches = !is.na(pos.matches);
    neg.matches = !is.na(neg.matches);
    score = sum(pos.matches) - sum(neg.matches);
    return(score);
  }, pos.words, neg.words, .progress=.progress );
  scores.df = data.frame(score=scores, text=sentences);
  return(scores.df);
}
#to score all delta tweets
delta.scores = score.sentiment(delta.text, pos.words, neg.words, .progress='text')

#let's add 2 more columns to identify the airline
delta.scores$airline = 'Delta'
delta.scores$code = 'DL'



#RESTART R session!
#this method avoids explicit handshake
#had to set up a developer account through Twitter
#create new app
#used my wordpress as my website
#callback URL WAS: http://127.0.0.1:1410
library(devtools)
library(twitteR)
library(SnowballC)
library(tm)
library(syuzhet)

consumerKey <- "ZKPNweFiEevZ44LunMTm7Zdvb"
consumerSecret <- "7xivTtVRJZ6yz5IfMOYtn9fXXm6AwGy2drWHbpNXqPvbcDPpRi"
accessToken <- "4175840296-Q0lpwHThWNalIsQlOLNuatvC5HzbAeNhtKYLqOD"
accessTokenSecret <- "5ZEXZNlwfTo3MgYNabAAa8yzIyDWAsZ1sIJJnMr5anW4g"

setup_twitter_oauth(consumerKey, consumerSecret, accessToken, accessTokenSecret)

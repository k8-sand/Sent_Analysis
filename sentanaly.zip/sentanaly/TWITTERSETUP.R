#retrieving the twitteR package
library(twitteR)
delta.tweets = searchTwitter('@delta',n=1500)
install.packages(c("devtools", "rjson", "bit64", "httr"))

#RESTART R session!

library(devtools)
library(twitteR)
api_key <- "ZKPNweFiEevZ44LunMTm7Zdvb"

api_secret <- "7xivTtVRJZ6yz5IfMOYtn9fXXm6AwGy2drWHbpNXqPvbcDPpRi"

access_token <- "4175840296-Q0lpwHThWNalIsQlOLNuatvC5HzbAeNhtKYLqOD"

access_token_secret <- "5ZEXZNlwfTo3MgYNabAAa8yzIyDWAsZ1sIJJnMr5anW4g"

setup_twitter_oauth(api_key,api_secret)
